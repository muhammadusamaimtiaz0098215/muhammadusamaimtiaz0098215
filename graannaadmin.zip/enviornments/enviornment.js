// const BASEURL_Check = () => {
//   let BaseURL = "https://graana.virtual-force.io/customerservice";

//   return BaseURL;
// };

export const env = {
  BaseURL: "https://graana.virtual-force.io/adminserver",

  CityURL: "https://graana.com/api/city",

  AreaURL: "https://www.graana.com/api/city/areas?city_id=",

  CategoryURL:
    "https://graana.virtual-force.io/customerservice/api/v1/categories",
};
// https://graana.virtual-force.io/adminserver/api/v1/auth/login
