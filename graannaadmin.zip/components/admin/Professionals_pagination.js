import { useEffect } from "react";
import { Get_Profesionals } from "../../pages/api/apiCalls";

function Professionals_pagination() {
  useEffect(() => {});
  return <div></div>;
}

export default Professionals_pagination;
